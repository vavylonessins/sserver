"""..."""

from sserver import *
import os


ss = Ss()

# We can use random free socket :)
ss.init("localhost")

# noinspection HttpUrlsUsage
print("Server started at http://"+ss.host+":"+ss.port+"/")

ss.set_root(os.path.abspath(".").removesuffix("/")+"/htdocs")


@ss.handler("GET")
def func(request):
    """ standard GET handler"""
    path = request.path.normalize()
    if not os.path.exists(str(path)):
        return Responce("HTTP/1.0", "404 NOT FOUND", "File not found")
    else:
        ret = Responce("HTTP/1.0", "200 OK", autoload(path))
        return ret


ss.polling()
